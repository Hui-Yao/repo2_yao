# makeyourownneuralnetwork
Code for the Make Your Own Neural Network book

blog: https://makeyourownneuralnetwork.blogspot.com/
